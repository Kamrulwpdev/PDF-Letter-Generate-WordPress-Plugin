<?php if (!defined('ABSPATH')) exit; ?>

<div class="letter-container">
    <p><?php echo esc_html($data['recipient_name']); ?></p>
    <p><?php echo nl2br(esc_html($data['address'])); ?></p>
	 <p><?php echo esc_html($data['title']); ?></p>
    <br>
    <p><?php echo nl2br(esc_html($data['message'])); ?></p>
    <br>
    <p>Sincerely,</p>
    <p><?php echo esc_html($data['recipient_name']); ?></p>
</div>

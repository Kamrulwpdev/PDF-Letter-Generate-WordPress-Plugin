jQuery(document).ready(function($) {
    $('#generate-letter').on('click', function() {
        console.log("Generate Letter button clicked!");

        let recipient_name = $('input[name="recipient_name"]').val();
        let title = $('input[name="title"]').val();
        let address = $('textarea[name="address"]').val();
        let message = $('textarea[name="message"]').val();

        if (!recipient_name || !title || !address || !message) {
            alert("Please fill out all fields before generating the letter.");
            return;
        }

        console.log("Sending AJAX request...");

        $.ajax({
            url: wplg_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'wplg_generate_letter',
                data: {
                    recipient_name: recipient_name,
                    title: title,
                    address: address,
                    message: message
                }
            },
            success: function(response) {
                console.log("AJAX response:", response);
                if (response.success) {
                    let letterContent = response.data;
                    letterContent = letterContent.replace("Your Name", recipient_name);
                    $('#letter-output').html(letterContent);
                } else {
                    alert("Error generating letter: " + response.data);
                }
            },
            error: function(xhr, status, error) {
                console.log("AJAX Error:", status, error, xhr.responseText);
                alert("Letter generation failed.");
            }
        });
    });

    $('#generate_pdf').on('click', function() {
        let letterContent = $('#letter-output').html();

        if (!letterContent || letterContent.trim() === "") {
            alert("No letter content available. Please generate a letter first.");
            return;
        }

        console.log("Sending AJAX request for PDF...");

        $.ajax({
            url: wplg_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'wplg_generate_pdf',
                letter_content: letterContent
            },
            xhrFields: { responseType: 'blob' },
            success: function(response) {
                console.log("PDF received:", response);
                let blob = new Blob([response], { type: 'application/pdf' });
                let link = document.createElement('a');
                link.href = window.URL.createObjectURL(blob);
                link.download = 'Generated_Letter.pdf';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            },
            error: function(xhr, status, error) {
                console.log("AJAX Error:", status, error, xhr.responseText);
                alert('PDF generation failed.');
            }
        });
    });
	
	 $('#auto-fill').on('click', function() {
        $('input[name="recipient_name"]').val("Kamrul Hasan");
        $('input[name="title"]').val("This for a typical business letter to generate and download pdf.");
        $('textarea[name="address"]').val("123 Winner's Road\nNew Employee Town, PA 12345");
        $('textarea[name="message"]').val(
            "Dear Kamrul Hasan,\n\n" +
            "The first paragraph of a typical business letter is used to state the main point of the letter. " +
            "Begin with a friendly opening, then quickly transition into the purpose of your letter. Use a " +
            "couple of sentences to explain the purpose, but do not go into detail until the next paragraph.\n\n" +
            "Beginning with the second paragraph, state the supporting details to justify your purpose. " +
            "These may take the form of background information, statistics, or first-hand accounts. A " +
            "few short paragraphs within the body of the letter should be enough to support your " +
            "reasoning.\n\n" +
            "Finally, in the closing paragraph, briefly restate your purpose and why it is important. " +
            "If the purpose of your letter is employment-related, consider ending your letter with your contact " +
            "information. However, if the purpose is informational, think about closing with gratitude for " +
            "the reader’s time.\n\n"
        );
    });
});
